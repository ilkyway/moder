from telethon import TelegramClient, events,functions

# Replace the values below with your own API ID and API hash from the Telegram website
api_id = 24099364
api_hash = '17dcf4fcfa05165415cd09f7677a102b'

# Replace the values below with your own bot token and chat ID
zixid = [2128970845,6111425195]
chat_id = -1001726091917
job_chat = 1664146745

# Initialize the Telegram client
client = TelegramClient('userbot_session', api_id, api_hash).start()

# Define a handler function for the "/neo" command
@client.on(events.NewMessage(chats=chat_id, pattern='.neo'))
async def neo_handler(event):
    if event.sender_id in zixid:
    # Get the text message to send as a reply
    	reply_text = event.message.text[5:].strip()  # remove "/neo" from the beginning
    # Get the message to which the command was answered
    	replied_to = await event.get_reply_message()
    	if replied_to:
        # Reply to the message
        	await client.send_message(chat_id, reply_text, reply_to=replied_to)
    	else:
        	await client.send_message(chat_id, reply_text)
@client.on(events.NewMessage(pattern='.job'))
async def neo_inf(event):
    replied_to = await event.get_reply_message()
    if event.sender_id in zixid:
    	await client(functions.messages.SendMessageRequest(peer=1664146745,message=f"https://t.me/fukksleepchat/{replied_to.id} #job",reply_to_msg_id=31715))
    	await event.reply("Send!")
# Start the client
client.run_until_disconnected()